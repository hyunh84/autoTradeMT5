from PyQt5.QtWidgets import (
    QWidget, QLabel, QComboBox, QPushButton, QTableWidget, QTableWidgetItem, QTextEdit,
    QHBoxLayout, QVBoxLayout, QLineEdit, QHeaderView, QSizePolicy
)
from PyQt5.QtGui import QColor, QFont, QBrush
from PyQt5.QtCore import Qt, pyqtSignal
import sys

import MetaTrader5 as mt5
from strategy.Ichimoku_Strategy import IchimokuBreakoutStrategy
from dataMT5.collector import get_mt5_ohlcv  # ★ MT5 캔들 데이터 함수 import

STRATEGY_DICT = {
    "Ichimoku Breakout": IchimokuBreakoutStrategy,
}

class BacktestWindow(QWidget):
    go_main_signal = pyqtSignal()  # 메인으로 전환 시그널
    def __init__(self):
        super().__init__()
        self.setWindowTitle("전략 백테스트")
        self.setGeometry(200, 200, 500, 700)
        self.init_ui()

    def init_ui(self):
        main_layout = QVBoxLayout()
        main_layout.setSpacing(5)
        main_layout.setContentsMargins(10, 10, 10, 10)

        # ---------- [GO Main] ----------
        btnTop_layout = QHBoxLayout()
        btnTop_layout.setSpacing(5)
        self.go_home_btn = QPushButton('홈')
        self.go_home_btn.setFixedHeight(34)
        self.go_home_btn.setStyleSheet("width: 100%; font-size: 15px; background-color: #cccccc; font-weight: bold;")
        self.go_home_btn.clicked.connect(self.go_main)
        btnTop_layout.addWidget(self.go_home_btn)
        main_layout.addLayout(btnTop_layout)

        # ---------- [상단 : 전략 선택] ----------
        top_layout = QHBoxLayout()
        self.strategy_cb = QComboBox()
        self.strategy_cb.addItems(list(STRATEGY_DICT.keys()))
        top_layout.addWidget(QLabel("전략 선택 박스"))
        top_layout.addWidget(self.strategy_cb)
        top_layout.addStretch()
        main_layout.addLayout(top_layout)

        # ---------- [테스트 시작 버튼] ----------
        self.start_btn = QPushButton("테스트 시작")
        self.start_btn.setFixedHeight(36)
        self.start_btn.setStyleSheet("background-color: #1590b2; color: white; font-size: 22px; font-weight: bold;")
        self.start_btn.clicked.connect(self.run_backtest)  # ★ 연결
        main_layout.addWidget(self.start_btn)

        # ---------- [계좌/원금/총수익 테이블] ----------
        self.info_table = QTableWidget(2, 4)
        self.info_table.setFixedHeight(85)
        self.info_table.horizontalHeader().setVisible(False)
        self.info_table.verticalHeader().setVisible(False)
        self.info_table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.info_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.info_table.setStyleSheet("""
            QTableWidget {
                margin: 0px; padding: 0px; border: none;
            }
            QTableCornerButton::section {
                background: white; border: none; margin: 0px;
            }
        """)
        title_bg = QBrush(QColor("#156082"))
        title_fg = QBrush(Qt.white)
        bold_font = QFont()
        bold_font.setBold(True)

        tblItem = QTableWidgetItem("종목")
        tblItem.setBackground(title_bg)
        tblItem.setForeground(title_fg)
        tblItem.setFont(bold_font)
        tblItem.setTextAlignment(Qt.AlignCenter)
        self.info_table.setItem(0, 0, tblItem)
        self.info_table.setItem(0, 1, QTableWidgetItem("GBPJPY, Great Britain Pound vs Japanese Yen "))
        tblItem = QTableWidgetItem("투자금")
        tblItem.setBackground(title_bg)
        tblItem.setForeground(title_fg)
        tblItem.setFont(bold_font)
        tblItem.setTextAlignment(Qt.AlignCenter)
        self.info_table.setItem(1, 0, tblItem)

        self.input_invest = QLineEdit()
        self.input_invest.setPlaceholderText("금액 입력")
        self.info_table.setCellWidget(1, 1, self.input_invest)

        tblItem = QTableWidgetItem("총 수익")
        tblItem.setBackground(title_bg)
        tblItem.setForeground(title_fg)
        tblItem.setFont(bold_font)
        tblItem.setTextAlignment(Qt.AlignCenter)
        self.info_table.setItem(1, 2, tblItem)      
        self.info_table.setSpan(0, 1, 1, 3)

        main_layout.addWidget(self.info_table)

        # ---------- [거래내역 테이블] ----------
        self.trade_table = QTableWidget(0, 4)
        self.trade_table.setHorizontalHeaderLabels(["날짜", "포지션", "가격", "수익"])
        self.trade_table.setFixedHeight(200)
        self.trade_table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.trade_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.trade_table.setStyleSheet("""
            QTableWidget {
                margin: 0px; padding: 0px; border: none;
            }
            QTableCornerButton::section {
                border: none; margin: 0px; padding: 0px;
            }
        """)
        main_layout.addWidget(self.trade_table)
        
        # ---------- [콘솔 로그 영역] ----------
        self.console = QTextEdit()
        self.console.setPlaceholderText("로그가 여기에 표시됩니다.")
        self.console.setReadOnly(True)
        self.console.setFixedHeight(330)
        self.console.setStyleSheet("""
        QTextEdit {
            font-family: Consolas,monospace; margin: 0px; padding: 0px; border: none;
        }
        """)
        main_layout.addWidget(self.console)

        self.setLayout(main_layout)

    def go_main(self):
        self.go_main_signal.emit()

    # ★★★★★ 핵심 추가: MT5 데이터로 전략 실행 & 결과 표시 ★★★★★
    def run_backtest(self):
        # 1. MT5에서 데이터 불러오기 (기본: GBPJPY, 300봉, 1시간봉)
        df = get_mt5_ohlcv(symbol="GBPJPY", n=1000, timeframe=mt5.TIMEFRAME_H1)
        if df is None:
            self.console.append("캔들 데이터 없음! MT5 연결 또는 심볼 확인.")
            return
        # 2. 전략 선택 및 실행
        strategy_name = self.strategy_cb.currentText()
        StrategyClass = STRATEGY_DICT[strategy_name]
        strategy = StrategyClass()
        result_df = strategy.run(df, self.console.append)
        # 3. 거래내역/총수익 테이블, 로그에 결과 출력
        self.update_trade_table(result_df)
        self.update_total_pnl(result_df)
        self.console.append(f"{strategy_name} 테스트 완료! 총 수익: {result_df['pnl'].sum():.2f}")

    def update_trade_table(self, result_df):
        # 거래 발생 row만 추출 (수익이 0이 아닌 행만)
        trade_logs = result_df[result_df['pnl'] != 0]
        self.trade_table.setRowCount(len(trade_logs))
        for i, (idx, row) in enumerate(trade_logs.iterrows()):
            self.trade_table.setItem(i, 0, QTableWidgetItem(str(row.get('time', ''))))
            self.trade_table.setItem(i, 1, QTableWidgetItem(str(row.get('position', ''))))
            self.trade_table.setItem(i, 2, QTableWidgetItem(str(row.get('entry_price', ''))))
            self.trade_table.setItem(i, 3, QTableWidgetItem(f"{row.get('pnl', 0):.2f}"))

    def update_total_pnl(self, result_df):
        total_pnl = result_df['pnl'].sum()
        self.info_table.setItem(1, 3, QTableWidgetItem(f"{total_pnl:.2f}"))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    w = BacktestWindow()
    w.show()
    sys.exit(app.exec_())
