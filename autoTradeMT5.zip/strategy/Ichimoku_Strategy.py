# Ichimoku_Strategy.py
import numpy as np

class IchimokuBreakoutStrategy():
	def __init__(self, pip=0.010):
		self.pip = pip
		self.spread = 3 * pip
		self.tp_pips = 15 * pip + self.spread
		self.sl_pips = 15 * pip

	def calculate_ichimoku(self, df):
		df = df.copy()
		df['conversion'] = (df['high'].rolling(9).max() + df['low'].rolling(9).min()) / 2
		df['base'] = (df['high'].rolling(26).max() + df['low'].rolling(26).min()) / 2
		df['leading_span1'] = ((df['conversion'] + df['base']) / 2).shift(26)
		df['leading_span2'] = ((df['high'].rolling(52).max() + df['low'].rolling(52).min()) / 2).shift(26)
		df['kumo_high'] = df[['leading_span1', 'leading_span2']].max(axis=1)
		df['kumo_low'] = df[['leading_span1', 'leading_span2']].min(axis=1)
		df['high26'] = df['high'].shift(26)
		df['low26'] = df['low'].shift(26)
		return df

	def run(self, df, log_fn=None):
		if log_fn is None:
			log_fn = print  # fallback

		df = self.calculate_ichimoku(df)
		df['signal'] = 0

		log_fn(f'{df}')

		# --- 진입조건 계산 (NaN 구간 방지, 트레이딩뷰 타이밍 동기화!) ---
		bull_cross = (df['conversion'] > df['base']) & (df['conversion'].shift(1) <= df['base'].shift(1))
		bear_cross = (df['conversion'] < df['base']) & (df['conversion'].shift(1) >= df['base'].shift(1))
		conversion_rising = (df['conversion'] - df['conversion'].shift(1)) >= 4 * self.pip
		conversion_falling = (df['conversion'].shift(1) - df['conversion']) >= 4 * self.pip

		# 신호가 발생한 "다음 봉"에서 진입해야 트레이딩뷰와 같음! (shift로 한 칸 미루기)
		long_cond = (
			bull_cross &
			(df['conversion'] > df['kumo_high']) &
			(df['base'] > df['kumo_high']) &
			(df['close'] > df['high26']) &
			(df['close'] > df['conversion']) &
			conversion_rising
		)
		short_cond = (
			bear_cross &
			(df['conversion'] < df['kumo_low']) &
			(df['base'] < df['kumo_low']) &
			(df['close'] < df['low26']) &
			(df['close'] < df['conversion']) &
			conversion_falling
		)
		# NaN 구간 제거 (필수!)
		valid_cond = (
			df['conversion'].notnull() & df['base'].notnull() &
			df['kumo_high'].notnull() & df['kumo_low'].notnull() &
			df['high26'].notnull() & df['low26'].notnull()
		)
		long_cond &= valid_cond
		short_cond &= valid_cond

		# --- 실제 진입 신호는 한 칸 "뒤"에서 발생
		df['signal'] = 0
		df.loc[long_cond.shift(1, fill_value=False), 'signal'] = 1
		df.loc[short_cond.shift(1, fill_value=False), 'signal'] = -1

		if log_fn:
			log_fn(f"long_cond True 개수(원신호): {long_cond.sum()}")
			log_fn(f"short_cond True 개수(원신호): {short_cond.sum()}")
			log_fn(f"long signal 진입 총 {int((df['signal']==1).sum())}회 / short {int((df['signal']==-1).sum())}회")

		# --- 실제 포지션 관리 ---
		df['position'] = 0
		df['entry_price'] = np.nan
		df['pnl'] = 0.0
		position = 0
		entry_price = 0
		entry_bar = 0

		for i in range(len(df)):
			# 이미 포지션이 없을 때 진입 신호 → 진입
			if position == 0 and df['signal'].iat[i] == 1:
				position = 1
				entry_price = df['close'].iat[i]
				entry_bar = i
				df.at[df.index[i], 'position'] = 1
				df.at[df.index[i], 'entry_price'] = entry_price
				if log_fn: log_fn(f"[Long 진입] {df['time'].iat[i]} / 진입가: {entry_price}")
			elif position == 0 and df['signal'].iat[i] == -1:
				position = -1
				entry_price = df['close'].iat[i]
				entry_bar = i
				df.at[df.index[i], 'position'] = -1
				df.at[df.index[i], 'entry_price'] = entry_price
				if log_fn: log_fn(f"[Short 진입] {df['time'].iat[i]} / 진입가: {entry_price}")

			# 롱 포지션 종료 조건
			if position == 1:
				# 익절
				if df['close'].iat[i] >= entry_price + self.tp_pips:
					df.at[df.index[i], 'pnl'] = df['close'].iat[i] - entry_price
					if log_fn: log_fn(f"[Long 익절] {df['time'].iat[i]} / 청산가: {df['close'].iat[i]}")
					position = 0
					entry_price = 0
				# 손절
				elif (i > entry_bar) and (df['open'].iat[i] < df['low26'].iat[i]):
					df.at[df.index[i], 'pnl'] = df['open'].iat[i] - entry_price
					if log_fn: log_fn(f"[Long 손절] {df['time'].iat[i]} / 청산가: {df['open'].iat[i]}")
					position = 0
					entry_price = 0

			# 숏 포지션 종료 조건
			if position == -1:
				# 익절
				if df['close'].iat[i] <= entry_price - self.tp_pips:
					df.at[df.index[i], 'pnl'] = entry_price - df['close'].iat[i]
					if log_fn: log_fn(f"[Short 익절] {df['time'].iat[i]} / 청산가: {df['close'].iat[i]}")
					position = 0
					entry_price = 0
				# 손절
				elif (i > entry_bar) and (df['open'].iat[i] > df['high26'].iat[i]):
					df.at[df.index[i], 'pnl'] = entry_price - df['open'].iat[i]
					if log_fn: log_fn(f"[Short 손절] {df['time'].iat[i]} / 청산가: {df['open'].iat[i]}")
					position = 0
					entry_price = 0

			df.at[df.index[i], 'position'] = position

		return df
